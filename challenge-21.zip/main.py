class BankAccount:
    def_init_(self,account_number, account_holder_name, account_balance):
  self._account_number=account_number
  self._account_holder_name=account_holder_name
self._account_balance=account_balance

def deposit (self,amount):
  self._account_balance+=amount

def withdraw(self, amount):
  if amount> self._account_balance:
    raise ValueError("Insufficient balance")
    self._account_balance-=amount
    
def get_account_balance(self):
  bank_account=BankAccount(1234567890,"John Doe",1000)
  #Deposit 500
 bank_account.deposit(500)

#withdraw 200
bank_account.withdraw(200)

#Get the account balance
account_balance=bank_account.get_account_balance()

#print the account balance
print (account_balance)