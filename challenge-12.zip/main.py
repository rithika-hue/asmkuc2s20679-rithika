# Leap Year

"""
year%4==0
year%100!=O/
year%400==0

"""
defisLeap Year(year):
 if(year%4==0 and year%100!=00)or year%400==0:
 return True
else: 
 return False

year=int(input("Enter a year:"))

if isLeap Year(year):
print('{}is a leap year.'. format(year))
else:
 print('{}is not a leap year.'. format(year)) 

